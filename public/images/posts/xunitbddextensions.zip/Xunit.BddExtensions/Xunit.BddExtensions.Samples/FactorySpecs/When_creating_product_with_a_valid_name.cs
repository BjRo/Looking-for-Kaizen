using XunitExt;

namespace Xunit.BddExtensions.Samples.FactorySpecs
{
    [Concern(typeof(Factory))]
    public class When_creating_product_with_a_valid_name : ContextSpecification
    {
        private Factory _Factory;
        private Product _CreatedProduct;

        protected override void EstablishContext()
        {
            _Factory = new Factory();
        }

        protected override void Because()
        {
            _CreatedProduct = _Factory.Create("Foo");
        }

        [Observation]
        public void The_product_should_contain_the_correct_name()
        {
            _CreatedProduct.Name.ShouldEqual("Foo");
        }

        [Observation]
        public void The_product_should_contain_the_correct_vendor_name()
        {
            _CreatedProduct.VendorName.ShouldEqual("FooVendor");
        }
    }
}