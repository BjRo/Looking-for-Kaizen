using System;

namespace Xunit.BddExtensions.Samples.FactorySpecs
{
    [Concern(typeof(Factory))]
    public class When_attemting_to_create_an_unknown_product : ContextSpecification
    {
        private Factory _Factory;
        private Action _Action;

        protected override void EstablishContext()
        {
            _Factory = new Factory();
        }

        protected override void Because()
        {
            _Action = () => _Factory.Create("Bar");
        }

        [Observation]
        public void Should_throw_An_InvalidOperationException()
        {
            _Action.ShouldThrowAn<InvalidOperationException>();
        }
    }
}