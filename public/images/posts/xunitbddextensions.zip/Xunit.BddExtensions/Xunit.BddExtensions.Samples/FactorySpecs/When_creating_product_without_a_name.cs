using System;

namespace Xunit.BddExtensions.Samples.FactorySpecs
{
    [Concern(typeof(Factory))]
    public class When_creating_product_without_a_name : ContextSpecification
    {
        private Factory _Factory;
        private Action _CreateAction;

        protected override void EstablishContext()
        {
            _Factory = new Factory();
        }

        protected override void Because()
        {
            _CreateAction = () => _Factory.Create(null);
        }

        [Observation]
        public void Should_throw_an_ArgumentNullException()
        {
            _CreateAction.ShouldThrowAn<ArgumentNullException>();
        }
    }
}