using System;

namespace Xunit.BddExtensions.Samples
{
    public class Factory
    {
        public Product Create(string productName)
        {
            if (productName == null)
            {
                throw new ArgumentNullException("productName");
            }

            if (!string.Equals(productName, "Foo"))
            {
                throw new InvalidOperationException("Unknown product");
            }
            
            return new Product {Name = "Foo", VendorName = "FooVendor"};
        }
    }
}