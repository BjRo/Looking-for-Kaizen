namespace Xunit.BddExtensions.Samples
{
    public class Product
    {
        public string Name;
        public string VendorName;
    }
}