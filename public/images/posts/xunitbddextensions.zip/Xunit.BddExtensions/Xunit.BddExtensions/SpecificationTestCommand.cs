using System;
using System.Reflection;
using Xunit.Sdk;

namespace Xunit
{
    /// <summary>
    /// A test command for specifications.
    /// </summary>
    public class SpecificationTestCommand : BeforeAfterCommand
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SpecificationTestCommand"/> class.
        /// </summary>
        /// <param name="innerCommand">The inner command.</param>
        /// <param name="testMethod">The test method.</param>
        public SpecificationTestCommand(
            ITestCommand innerCommand,
            MethodInfo testMethod)
            : base(innerCommand, testMethod)
        {
        }

        /// <summary>
        /// Executes the test
        /// </summary>
        /// <param name="testClass">The test instance.</param>
        /// <exception cref="InvalidOperationException">
        /// Thrown when the test instance does not implement the <see cref="IContextSpecification"/>
        /// interface.
        /// </exception>
        public override MethodResult Execute(object testClass)
        {
            var specification = testClass as IContextSpecification;

            try
            {
                if (specification == null)
                {
                    throw new InvalidOperationException("Instance does not implement IContextSpecification");
                }

                specification.EstablishContext();
                specification.Because();
                return base.Execute(testClass);
            }
            catch(AssertException)
            {
                throw;
            }
            catch (Exception exception)
            {
                ExceptionUtility.RethrowWithNoStackTraceLoss(exception.InnerException);
            }

            return null;
        }
    }
}