using System;

namespace Xunit
{
    public static class BddExtensions
    {
        public static void ShouldThrowAn<TException>(this Action action) where TException : Exception
        {
            Assert.Throws<TException>(() => action());
        }
    }
}