﻿using System;

namespace Xunit
{
    /// <summary>
    /// Base class for context specifications.
    /// </summary>
    public abstract class ContextSpecification : IContextSpecification, IDisposable
    {
        protected abstract void Because();

        protected abstract void EstablishContext();

        protected virtual void AfterEachSpec()
        {
        }
        
        #region IContextSpecification Members

        /// <summary>
        /// Is Called to execute the test.
        /// </summary>
        void IContextSpecification.Because()
        {
            Because();
        }

        /// <summary>
        /// Is called to setup the context for the test.
        /// </summary>
        void IContextSpecification.EstablishContext()
        {
            EstablishContext();
        }

        #endregion

        #region IDisposable Members

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            AfterEachSpec();
        }

        #endregion
    }
}