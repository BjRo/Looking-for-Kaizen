using System;

namespace Xunit
{
    /// <summary>
    /// Marks specifications to be related to a particular type
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
    public class ConcernAttribute : TraitAttribute
    {
        private readonly Type _Type;

        /// <summary>
        /// Initializes a new instance of the <see cref="ConcernAttribute"/> class.
        /// </summary>
        /// <param name="type">The type.</param>
        public ConcernAttribute(Type type) : base("Concern", type.FullName)
        {
            _Type = type;
        }

        /// <summary>
        /// Gets the type to which this concern is related.
        /// </summary>
        public Type Type
        {
            get { return _Type; }
        }
    }
}