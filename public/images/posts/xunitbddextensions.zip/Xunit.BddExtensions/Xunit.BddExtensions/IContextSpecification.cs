namespace Xunit
{
    /// <summary>
    /// Interface for a context specification.
    /// </summary>
    public interface IContextSpecification
    {
        /// <summary>
        /// Is Called to execute the test.
        /// </summary>
        void Because();

        /// <summary>
        /// Is called to setup the context for the test.
        /// </summary>
        void EstablishContext();
    }
}